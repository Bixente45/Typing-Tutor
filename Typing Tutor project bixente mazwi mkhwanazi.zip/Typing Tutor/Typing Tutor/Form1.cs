﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//AUTHOR: BIXENTE MAZWI MKHWANAZI
//CREATED: 12 APRIL 2024
//DESCRIPTION: THIS A SIMPLE TUTOR GAME THAT PROMPTS USER TO ENTER LETTERS TILL GAME IS FINISHED

namespace Typing_Tutor
{
    public partial class Form1 : Form
    {
        Random random = new Random();
        int totalGuesses = 0;
        int correctGuesses = 0;
        int incorrectGuesses = 0;
        int letterStartRange = 0;
        int letterEndRange = 0;
        bool mix = false;
        public Form1()
        {
            InitializeComponent();
        }

        private void timerGame_Tick(object sender, EventArgs e)
        {
            Random mixLetters = new Random();
            if (!mix)
            {

                enteredLetters.Items.Add((char)random.Next(letterStartRange, letterEndRange + 1));
            }//add into listbox

            if (mix) 
            {
                if (mixLetters.Next(1, 11) % 2 == 0)
                {
                    enteredLetters.Items.Add((char)random.Next(65, 90 + 1));

                }
                else 
                {
                    enteredLetters.Items.Add((char)random.Next(97, 122 + 1));
                }
            }
            if (enteredLetters.Items.Count > 7) 
            {
                enteredLetters.Items.Clear();
                enteredLetters.Items.Add("Game is officially over");
                timerGame.Stop(); // if letters are over seven, the game will officially be over
                splitContainer1.Panel1.Enabled = true; //enabled again when current game is over
                mix = false; // back to false when game is over
            }
        }

        private void startGame_Click(object sender, EventArgs e)
        {
            enteredLetters.Focus(); //putting focus is basically diverting from listbox
            timerGame.Start(); //this will start the timer control
            startGame.Enabled = false; //disable strt button as it clicks, as soon as user starts game, startbutton will be deactivated
            splitContainer1.Panel1.Enabled = false; // user cannot initialize while game is running
        }

        private void enteredLetters_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (enteredLetters.Items.Contains(e.KeyChar))
            {
                enteredLetters.Items.Remove(e.KeyChar);
                enteredLetters.Refresh();

                updateRecord(true);
            }
            else 
            {
                updateRecord(false);
            }

            tsStatusLabel.Text = "Total Guesses: " + totalGuesses + " Correct Guesses: " + correctGuesses + "Incorrect Guesses: " + incorrectGuesses;
        }

        private void updateRecord(bool isCorrect) 
        {
            totalGuesses++;
            if (isCorrect)
            {
                correctGuesses++;
            }
            else 
            {
                incorrectGuesses++;
            }
        }

        private void initializeButton_Click(object sender, EventArgs e)
        {
            startGame.Enabled = true; //connecting the initialize button to the program
            enteredLetters.Items.Clear();
            totalGuesses = 0;
            correctGuesses = 0;
            incorrectGuesses = 0;
            //control which button is checked
            if (radioCapital.Checked == true) 
            {
                letterStartRange = 65;
                letterEndRange = 90;
            }
            if (radioSmall.Checked == true) 
            {
                letterStartRange = 97;
                letterEndRange = 122;
            }
            if (radioMix.Checked == true) 
            {
                mix = true;
            }
            if (radioBeginner.Checked == true)
            {
                timerGame.Interval = 1000;
            }
            if (radioAverage.Checked == true) 
            {
                timerGame.Interval = 750;
            }
            if (radioAdvanced.Checked == true)
            {
                timerGame.Interval = 500;//checking the radio buttons to the corect time intervals
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            tsStatusLabel.Text = "Total Guesses: " + totalGuesses + " Correct Guesses: " + correctGuesses + "Incorrect Guesses: " + incorrectGuesses;
            radioCapital.Checked = true;
            radioBeginner.Checked = true;
        }
    }
}
