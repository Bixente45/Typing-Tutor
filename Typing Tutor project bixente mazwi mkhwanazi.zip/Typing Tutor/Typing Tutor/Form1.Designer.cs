﻿namespace Typing_Tutor
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.tsStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.startGame = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.enteredLetters = new System.Windows.Forms.ListBox();
            this.timerGame = new System.Windows.Forms.Timer(this.components);
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.initializeButton = new System.Windows.Forms.Button();
            this.radioCapital = new System.Windows.Forms.RadioButton();
            this.radioBeginner = new System.Windows.Forms.RadioButton();
            this.radioSmall = new System.Windows.Forms.RadioButton();
            this.radioAverage = new System.Windows.Forms.RadioButton();
            this.radioMix = new System.Windows.Forms.RadioButton();
            this.radioAdvanced = new System.Windows.Forms.RadioButton();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.initializeButton);
            this.splitContainer1.Panel1.Controls.Add(this.label3);
            this.splitContainer1.Panel1.Controls.Add(this.groupBox2);
            this.splitContainer1.Panel1.Controls.Add(this.groupBox1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.statusStrip1);
            this.splitContainer1.Panel2.Controls.Add(this.startGame);
            this.splitContainer1.Panel2.Controls.Add(this.label2);
            this.splitContainer1.Panel2.Controls.Add(this.label1);
            this.splitContainer1.Panel2.Controls.Add(this.enteredLetters);
            this.splitContainer1.Size = new System.Drawing.Size(1244, 321);
            this.splitContainer1.SplitterDistance = 367;
            this.splitContainer1.TabIndex = 0;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsStatusLabel});
            this.statusStrip1.Location = new System.Drawing.Point(0, 299);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(873, 22);
            this.statusStrip1.TabIndex = 4;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // tsStatusLabel
            // 
            this.tsStatusLabel.Name = "tsStatusLabel";
            this.tsStatusLabel.Size = new System.Drawing.Size(118, 17);
            this.tsStatusLabel.Text = "toolStripStatusLabel1";
            // 
            // startGame
            // 
            this.startGame.Enabled = false;
            this.startGame.Location = new System.Drawing.Point(777, 238);
            this.startGame.Name = "startGame";
            this.startGame.Size = new System.Drawing.Size(84, 39);
            this.startGame.TabIndex = 3;
            this.startGame.Text = "START GAME";
            this.startGame.UseVisualStyleBackColor = true;
            this.startGame.Click += new System.EventHandler(this.startGame_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Yu Gothic Medium", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(261, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(396, 44);
            this.label2.TabIndex = 2;
            this.label2.Text = "TYPING TUTOR GAME";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(7, 130);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(707, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "Type the letter and will appear here. Game will end if there is more than 7 lette" +
    "rs in box.";
            // 
            // enteredLetters
            // 
            this.enteredLetters.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.enteredLetters.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.enteredLetters.FormattingEnabled = true;
            this.enteredLetters.ItemHeight = 46;
            this.enteredLetters.Location = new System.Drawing.Point(11, 153);
            this.enteredLetters.MultiColumn = true;
            this.enteredLetters.Name = "enteredLetters";
            this.enteredLetters.Size = new System.Drawing.Size(850, 50);
            this.enteredLetters.TabIndex = 0;
            this.enteredLetters.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.enteredLetters_KeyPress);
            // 
            // timerGame
            // 
            this.timerGame.Interval = 1000;
            this.timerGame.Tick += new System.EventHandler(this.timerGame_Tick);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radioAdvanced);
            this.groupBox1.Controls.Add(this.radioAverage);
            this.groupBox1.Controls.Add(this.radioBeginner);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.SystemColors.Highlight;
            this.groupBox1.Location = new System.Drawing.Point(190, 115);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(167, 100);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Speed";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.radioMix);
            this.groupBox2.Controls.Add(this.radioSmall);
            this.groupBox2.Controls.Add(this.radioCapital);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.SystemColors.Highlight;
            this.groupBox2.Location = new System.Drawing.Point(12, 115);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(160, 100);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Letters";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("MV Boli", 24.75F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(28, 42);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(323, 44);
            this.label3.TabIndex = 2;
            this.label3.Text = "INITIALIZE GAME";
            // 
            // initializeButton
            // 
            this.initializeButton.Location = new System.Drawing.Point(128, 251);
            this.initializeButton.Name = "initializeButton";
            this.initializeButton.Size = new System.Drawing.Size(105, 39);
            this.initializeButton.TabIndex = 3;
            this.initializeButton.Text = "Initialize";
            this.initializeButton.UseVisualStyleBackColor = true;
            this.initializeButton.Click += new System.EventHandler(this.initializeButton_Click);
            // 
            // radioCapital
            // 
            this.radioCapital.AutoSize = true;
            this.radioCapital.Location = new System.Drawing.Point(1, 20);
            this.radioCapital.Name = "radioCapital";
            this.radioCapital.Size = new System.Drawing.Size(118, 19);
            this.radioCapital.TabIndex = 0;
            this.radioCapital.TabStop = true;
            this.radioCapital.Text = "Capital Letters";
            this.radioCapital.UseVisualStyleBackColor = true;
            // 
            // radioBeginner
            // 
            this.radioBeginner.AutoSize = true;
            this.radioBeginner.Location = new System.Drawing.Point(7, 20);
            this.radioBeginner.Name = "radioBeginner";
            this.radioBeginner.Size = new System.Drawing.Size(153, 19);
            this.radioBeginner.TabIndex = 0;
            this.radioBeginner.TabStop = true;
            this.radioBeginner.Text = "Beginner(Speed 1s)";
            this.radioBeginner.UseVisualStyleBackColor = true;
            // 
            // radioSmall
            // 
            this.radioSmall.AutoSize = true;
            this.radioSmall.Location = new System.Drawing.Point(1, 44);
            this.radioSmall.Name = "radioSmall";
            this.radioSmall.Size = new System.Drawing.Size(110, 19);
            this.radioSmall.TabIndex = 1;
            this.radioSmall.TabStop = true;
            this.radioSmall.Text = "Small Letters";
            this.radioSmall.UseVisualStyleBackColor = true;
            // 
            // radioAverage
            // 
            this.radioAverage.AutoSize = true;
            this.radioAverage.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioAverage.ForeColor = System.Drawing.SystemColors.Highlight;
            this.radioAverage.Location = new System.Drawing.Point(7, 44);
            this.radioAverage.Name = "radioAverage";
            this.radioAverage.Size = new System.Drawing.Size(166, 19);
            this.radioAverage.TabIndex = 1;
            this.radioAverage.TabStop = true;
            this.radioAverage.Text = "Average(Speed 0.75s)";
            this.radioAverage.UseVisualStyleBackColor = true;
            // 
            // radioMix
            // 
            this.radioMix.AutoSize = true;
            this.radioMix.Location = new System.Drawing.Point(0, 68);
            this.radioMix.Name = "radioMix";
            this.radioMix.Size = new System.Drawing.Size(96, 19);
            this.radioMix.TabIndex = 2;
            this.radioMix.TabStop = true;
            this.radioMix.Text = "Mix Letters";
            this.radioMix.UseVisualStyleBackColor = true;
            // 
            // radioAdvanced
            // 
            this.radioAdvanced.AutoSize = true;
            this.radioAdvanced.Location = new System.Drawing.Point(6, 67);
            this.radioAdvanced.Name = "radioAdvanced";
            this.radioAdvanced.Size = new System.Drawing.Size(168, 19);
            this.radioAdvanced.TabIndex = 2;
            this.radioAdvanced.TabStop = true;
            this.radioAdvanced.Text = "Advanced(Speed 0,5s)";
            this.radioAdvanced.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1244, 321);
            this.Controls.Add(this.splitContainer1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.ListBox enteredLetters;
        private System.Windows.Forms.Button startGame;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel tsStatusLabel;
        private System.Windows.Forms.Timer timerGame;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button initializeButton;
        private System.Windows.Forms.RadioButton radioMix;
        private System.Windows.Forms.RadioButton radioSmall;
        private System.Windows.Forms.RadioButton radioCapital;
        private System.Windows.Forms.RadioButton radioAdvanced;
        private System.Windows.Forms.RadioButton radioAverage;
        private System.Windows.Forms.RadioButton radioBeginner;
    }
}

